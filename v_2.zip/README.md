# NestRideHub-Be

## Please run the following command from the root dir so you are able to upload files

```sh
mkdir ../public_html/media
```
